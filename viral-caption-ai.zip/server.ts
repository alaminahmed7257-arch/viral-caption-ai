import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));

// Server-side Gemini Client helper
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// API Route for Viral Caption Generation
app.post("/api/generate-captions", async (req, res) => {
  try {
    const {
      description,
      videoName,
      tone = "viral",
      targetPlatform = "General / Reels / TikTok / Shorts",
    } = req.body;

    if (!description || typeof description !== "string" || !description.trim()) {
      return res.status(400).json({
        error: "Please provide a valid video description to generate captions.",
      });
    }

    const ai = getGeminiClient();

    if (!ai) {
      // Graceful fallback response when API key is pending configuration
      const sampleTags = [
        "#viral",
        "#trending",
        "#reels",
        "#shorts",
        "#contentcreator",
        "#foryou",
        "#explorepage",
        "#fyp",
        "#videoviral",
        "#creators",
      ];
      return res.json({
        title: `🔥 Stop Scrolling! The Ultimate ${description.slice(0, 30).trim()} Revealed`,
        caption: `You won't believe what happened in this video! 🤯 Tap like and share with someone who needs to see this right now. What's your take on this? Drop a comment below! 👇`,
        hashtags: sampleTags,
        hookAlternatives: [
          `Wait till the very end of this... 😱`,
          `Nobody talks about this secret yet 👀`,
          `3 reasons why this will blow your mind 🚀`,
        ],
      });
    }

    const prompt = `You are an elite viral social media strategist and copywriter specializing in short-form and long-form video (TikTok, Instagram Reels, YouTube Shorts, Facebook Video).
Analyze the video context and description provided by the user:

Video File Name: "${videoName || "Selected video"}"
User Video Description: "${description.trim()}"
Target Vibe/Platform: "${targetPlatform}" (Tone: ${tone})

Generate the following:
1. "title": Exactly ONE highly clickable, high-retention, catchy title (under 75 characters) with emotional hook, curiosity gap, or punchy value proposition.
2. "caption": A short, viral-optimized caption (2 to 4 sentences) designed to maximize watch time, comments, and shares. Include an engaging Call-to-Action (CTA).
3. "hashtags": An array of EXACTLY 10 relevant, high-traffic and niche-specific hashtags formatted with '#' prefix (e.g. ["#viral", "#trending", ...]).
4. "hookAlternatives": Exactly 3 alternative punchy opening hook lines that creators can speak or overlay as on-screen text.

Format the response strictly using the requested JSON schema.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: {
              type: Type.STRING,
              description: "One catchy, click-worthy viral title for the video.",
            },
            caption: {
              type: Type.STRING,
              description: "A short, engaging caption with high-converting CTA.",
            },
            hashtags: {
              type: Type.ARRAY,
              items: {
                type: Type.STRING,
              },
              description: "Exactly 10 relevant hashtags starting with #.",
            },
            hookAlternatives: {
              type: Type.ARRAY,
              items: {
                type: Type.STRING,
              },
              description: "3 alternative viral hook text ideas.",
            },
          },
          required: ["title", "caption", "hashtags"],
        },
      },
    });

    const rawText = response.text || "{}";
    const parsedData = JSON.parse(rawText);

    // Validate and clean hashtags
    let cleanedHashtags: string[] = Array.isArray(parsedData.hashtags)
      ? parsedData.hashtags.map((tag: string) =>
          tag.trim().startsWith("#") ? tag.trim() : `#${tag.trim()}`
        )
      : [];

    if (cleanedHashtags.length < 10) {
      const fallbackTags = [
        "#viral",
        "#reels",
        "#shorts",
        "#trending",
        "#foryou",
        "#explorepage",
        "#fyp",
        "#contentcreator",
        "#viralvideo",
        "#instadaily",
      ];
      while (cleanedHashtags.length < 10) {
        const nextTag = fallbackTags[cleanedHashtags.length % fallbackTags.length];
        if (!cleanedHashtags.includes(nextTag)) {
          cleanedHashtags.push(nextTag);
        } else {
          cleanedHashtags.push(`#viral${cleanedHashtags.length + 1}`);
        }
      }
    }

    if (cleanedHashtags.length > 10) {
      cleanedHashtags = cleanedHashtags.slice(0, 10);
    }

    return res.json({
      title: parsedData.title || `Viral Video: ${description.slice(0, 40)}`,
      caption:
        parsedData.caption ||
        `Check this out! Drop your thoughts in the comments 👇`,
      hashtags: cleanedHashtags,
      hookAlternatives: parsedData.hookAlternatives || [
        "Wait till the end! 😱",
        "Did you know about this? 👀",
        "Share this with someone who needs it! ✨",
      ],
    });
  } catch (error: any) {
    console.error("Gemini Caption generation error:", error);
    return res.status(500).json({
      error: error.message || "Failed to generate viral captions with AI.",
    });
  }
});

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", app: "Viral Caption AI" });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Viral Caption AI Server running on http://localhost:${PORT}`);
  });
}

startServer();

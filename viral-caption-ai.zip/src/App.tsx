import React, { useState, useEffect } from "react";
import confetti from "canvas-confetti";
import { AndroidStatusBar } from "./components/AndroidStatusBar";
import { AndroidHeader } from "./components/AndroidHeader";
import { AndroidNavBar } from "./components/AndroidNavBar";
import { VideoPicker } from "./components/VideoPicker";
import { DescriptionSection } from "./components/DescriptionSection";
import { ResultSection } from "./components/ResultSection";
import { HistorySection } from "./components/HistorySection";
import { PresetsModal } from "./components/PresetsModal";
import { ProScreen } from "./components/ProScreen";
import { ShareModal } from "./components/ShareModal";
import { Toast, ToastMessage } from "./components/Toast";
import {
  CaptionResult,
  VideoInfo,
  AppTab,
  ToneOption,
  DailyUsageInfo,
} from "./types";
import {
  loadHistory,
  addHistoryItem,
  deleteHistoryItem,
  clearAllHistory,
  triggerHaptic,
  getDailyUsage,
  incrementDailyUsage,
  canGenerateToday,
  DAILY_FREE_GENERATION_LIMIT,
} from "./utils/storage";
import { generateLocalCaptions } from "./utils/captionGenerator";

export default function App() {
  const [currentTab, setCurrentTab] = useState<AppTab>("generator");
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [description, setDescription] = useState<string>("");
  const [tone, setTone] = useState<ToneOption>("viral");
  const [targetPlatform, setTargetPlatform] = useState<string>("TikTok");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedResult, setGeneratedResult] = useState<CaptionResult | null>(
    null
  );
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [history, setHistory] = useState<CaptionResult[]>([]);
  const [dailyUsage, setDailyUsage] = useState<DailyUsageInfo>({
    used: 0,
    maxDaily: DAILY_FREE_GENERATION_LIMIT,
    remaining: DAILY_FREE_GENERATION_LIMIT,
    resetDate: "",
  });
  const [isGalaxyFrame, setIsGalaxyFrame] = useState<boolean>(false);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [shareModalOpen, setShareModalOpen] = useState<boolean>(false);
  const [itemToShare, setItemToShare] = useState<CaptionResult | null>(null);

  // Initialize history and daily limit usage from localStorage
  useEffect(() => {
    const loaded = loadHistory();
    setHistory(loaded);
    const usage = getDailyUsage();
    setDailyUsage(usage);
  }, []);

  const showToast = (text: string, type: "success" | "error" | "info" = "success") => {
    setToast({
      id: Math.random().toString(36).slice(2),
      text,
      type,
    });
    setTimeout(() => {
      setToast(null);
    }, 3000);
  };

  // Generate captions with daily free limit enforcement
  const handleGenerate = async () => {
    if (!description.trim()) {
      showToast("Please enter a description for your video first.", "error");
      return;
    }

    // Check free plan daily generation ceiling (5 per 24 hours)
    if (!canGenerateToday()) {
      triggerHaptic("heavy");
      showToast(
        "Daily limit of 5 free generations reached! Reset in 24 hours or upgrade to Pro.",
        "info"
      );
      setCurrentTab("pro");
      return;
    }

    setIsGenerating(true);
    setIsSaved(false);

    try {
      // Simulate realistic AI generation latency for natural feedback
      await new Promise((resolve) => setTimeout(resolve, 750));

      const generated = generateLocalCaptions({
        description: description.trim(),
        videoName: videoInfo?.name,
        tone,
        targetPlatform,
      });

      const newResult: CaptionResult = {
        id: "cap-" + Date.now(),
        title: generated.title,
        caption: generated.caption,
        hashtags: generated.hashtags,
        hookAlternatives: generated.hookAlternatives,
        videoName: videoInfo?.name,
        videoSize: videoInfo?.sizeFormatted,
        videoDuration: videoInfo?.durationFormatted,
        description: description.trim(),
        tone,
        targetPlatform,
        createdAt: Date.now(),
      };

      // Deduct from daily usage count and update storage
      const updatedUsage = incrementDailyUsage();
      setDailyUsage(updatedUsage);

      setGeneratedResult(newResult);
      showToast(
        `Generated! ${updatedUsage.remaining} of ${updatedUsage.maxDaily} free daily generations remaining.`,
        "success"
      );

      // Trigger celebratory confetti
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8 },
        colors: ["#3b82f6", "#60a5fa", "#93c5fd", "#ffffff"],
      });
    } catch (err: any) {
      console.error("Caption generation failed:", err);
      showToast(err.message || "Failed to generate captions. Please try again.", "error");
    } finally {
      setIsGenerating(false);
    }
  };

  // Update editable fields
  const handleUpdateResult = (updated: Partial<CaptionResult>) => {
    if (!generatedResult) return;
    setGeneratedResult({
      ...generatedResult,
      ...updated,
    });
    setIsSaved(false);
  };

  // Save generated caption to history
  const handleSave = () => {
    if (!generatedResult) return;
    const updatedHistory = addHistoryItem(generatedResult);
    setHistory(updatedHistory);
    setIsSaved(true);
    showToast("Saved to phone history!", "success");

    confetti({
      particleCount: 50,
      spread: 70,
      origin: { y: 0.85 },
      colors: ["#10b981", "#6366f1", "#f59e0b"],
    });
  };

  // Share content using Android Native Share Sheet or fallback sheet
  const handleOpenShare = async (resultToShare?: CaptionResult) => {
    const target = resultToShare || generatedResult;
    if (!target) return;

    const fullShareText = `${target.title}\n\n${target.caption}\n\n${target.hashtags.join(" ")}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: target.title,
          text: fullShareText,
        });
        showToast("Shared via Android share sheet!", "success");
        return;
      } catch (err: any) {
        // If user cancelled, don't show error; if failed or unsupported, open modal
        if (err.name === "AbortError") {
          return;
        }
      }
    }

    setItemToShare(target);
    setShareModalOpen(true);
  };

  // Delete single history item
  const handleDeleteHistoryItem = (id: string) => {
    const updated = deleteHistoryItem(id);
    setHistory(updated);
    showToast("Deleted from history", "info");
  };

  // Clear all history
  const handleClearAllHistory = () => {
    clearAllHistory();
    setHistory([]);
    showToast("History cleared", "info");
  };

  // Restore history item to generator
  const handleRestoreToEditor = (item: CaptionResult) => {
    setGeneratedResult(item);
    setDescription(item.description);
    if (item.videoName) {
      setVideoInfo({
        name: item.videoName,
        sizeFormatted: item.videoSize || "Attached",
        durationFormatted: item.videoDuration,
        type: "video/mp4",
      });
    }
    setCurrentTab("generator");
    setIsSaved(true);
    showToast("Loaded saved caption into editor!", "info");
  };

  // Preset chosen from presets tab
  const handleSelectPreset = (presetDesc: string) => {
    setDescription(presetDesc);
    setCurrentTab("generator");
    showToast("Loaded prompt template into description!", "info");
  };

  return (
    <div
      id="viral-caption-app-root"
      className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col items-center justify-start antialiased selection:bg-blue-600 selection:text-white"
    >
      {/* Container - Option to toggle Galaxy S24 frame or fluid full-width layout */}
      <div
        className={`w-full transition-all duration-300 ${
          isGalaxyFrame
            ? "max-w-[430px] my-4 rounded-[40px] border-[8px] border-zinc-800 shadow-[0_25px_60px_rgba(0,0,0,0.9)] overflow-hidden bg-zinc-950"
            : "max-w-3xl min-h-screen bg-zinc-950 sm:border-x sm:border-zinc-800/80 shadow-2xl"
        } flex flex-col`}
      >
        {/* Android Status Bar */}
        <AndroidStatusBar />

        {/* Top App Bar with Tabs & Brand */}
        <AndroidHeader
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          historyCount={history.length}
          dailyUsage={dailyUsage}
          isGalaxyFrame={isGalaxyFrame}
          onToggleFrame={() => setIsGalaxyFrame(!isGalaxyFrame)}
        />

        {/* Main Content Body */}
        <main
          id="main-app-content"
          className="flex-1 p-4 sm:p-5 flex flex-col gap-4 overflow-y-auto pb-24"
        >
          {currentTab === "generator" && (
            <div className="flex flex-col gap-4 animate-in fade-in duration-200">
              {/* Feature 1 & 2: Video Selection from Phone Gallery */}
              <VideoPicker
                videoInfo={videoInfo}
                onSelectVideo={setVideoInfo}
                onSelectPresetPrompt={(desc, name) => {
                  setDescription(desc);
                  showToast(`Selected "${name}" preset!`, "info");
                }}
              />

              {/* Feature 3 & 4: Video Description Input & Generate Trigger with daily limit counter */}
              <DescriptionSection
                description={description}
                onChangeDescription={setDescription}
                tone={tone}
                onChangeTone={setTone}
                targetPlatform={targetPlatform}
                onChangeTargetPlatform={setTargetPlatform}
                onGenerate={handleGenerate}
                isGenerating={isGenerating}
                hasVideoSelected={Boolean(videoInfo)}
                dailyUsage={dailyUsage}
                onOpenPro={() => setCurrentTab("pro")}
              />

              {/* Feature 5, 6, 7, 8, 9: Generated Title, Caption, 10 Hashtags in Editable boxes + Copy/Save/Share */}
              {generatedResult && (
                <ResultSection
                  result={generatedResult}
                  onUpdateResult={handleUpdateResult}
                  onSave={handleSave}
                  onShare={() => handleOpenShare(generatedResult)}
                  onRegenerate={handleGenerate}
                  isGenerating={isGenerating}
                  isSaved={isSaved}
                />
              )}
            </div>
          )}

          {currentTab === "history" && (
            <div className="animate-in fade-in duration-200">
              {/* Feature 10 & 11: History Section & Delete functionality */}
              <HistorySection
                history={history}
                onDelete={handleDeleteHistoryItem}
                onClearAll={handleClearAllHistory}
                onRestore={handleRestoreToEditor}
                onShareItem={(item) => handleOpenShare(item)}
              />
            </div>
          )}

          {currentTab === "presets" && (
            <div className="animate-in fade-in duration-200">
              <PresetsModal onSelectPreset={handleSelectPreset} />
            </div>
          )}

          {currentTab === "pro" && (
            <div className="animate-in fade-in duration-200">
              {/* Pro Screen for Monetization Readiness */}
              <ProScreen
                dailyUsage={dailyUsage}
                onShowToast={showToast}
                onOpenGenerator={() => setCurrentTab("generator")}
              />
            </div>
          )}
        </main>

        {/* Android Material 3 Bottom Navigation Bar */}
        <AndroidNavBar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          historyCount={history.length}
        />
      </div>

      {/* Android Share Sheet Dialog */}
      <ShareModal
        isOpen={shareModalOpen}
        onClose={() => setShareModalOpen(false)}
        result={itemToShare}
      />

      {/* Floating Material 3 Snackbar Toast */}
      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </div>
  );
}

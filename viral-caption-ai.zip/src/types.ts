export interface CaptionResult {
  id: string;
  title: string;
  caption: string;
  hashtags: string[];
  hookAlternatives?: string[];
  videoName?: string;
  videoSize?: string;
  videoDuration?: string;
  videoThumbnail?: string;
  description: string;
  tone: string;
  targetPlatform: string;
  createdAt: number;
}

export interface VideoInfo {
  file?: File;
  name: string;
  sizeFormatted: string;
  durationFormatted?: string;
  url?: string;
  type: string;
}

export type AppTab = "generator" | "history" | "presets" | "pro";

export interface DailyUsageInfo {
  used: number;
  maxDaily: number;
  remaining: number;
  resetDate: string;
}

export type ToneOption = "viral" | "humorous" | "educational" | "dramatic" | "inspiring" | "urgent";

export interface ToneItem {
  id: ToneOption;
  label: string;
  emoji: string;
  description: string;
}

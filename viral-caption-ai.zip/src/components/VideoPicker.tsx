import React, { useRef } from "react";
import { Video, Upload, Film, X, Play, CheckCircle2 } from "lucide-react";
import { VideoInfo } from "../types";
import { triggerHaptic } from "../utils/storage";

interface VideoPickerProps {
  videoInfo: VideoInfo | null;
  onSelectVideo: (info: VideoInfo | null) => void;
}

export const VideoPicker: React.FC<VideoPickerProps> = ({
  videoInfo,
  onSelectVideo,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    triggerHaptic("medium");

    // Format file size
    const sizeInMB = (file.size / (1024 * 1024)).toFixed(1);
    const sizeFormatted = `${sizeInMB} MB`;
    const objectUrl = URL.createObjectURL(file);

    // Get video duration via temporary video element
    const tempVideo = document.createElement("video");
    tempVideo.preload = "metadata";
    tempVideo.src = objectUrl;
    tempVideo.onloadedmetadata = () => {
      const minutes = Math.floor(tempVideo.duration / 60);
      const seconds = Math.floor(tempVideo.duration % 60);
      const durationFormatted = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;

      onSelectVideo({
        file,
        name: file.name,
        sizeFormatted,
        durationFormatted,
        url: objectUrl,
        type: file.type || "video/mp4",
      });
    };

    tempVideo.onerror = () => {
      onSelectVideo({
        file,
        name: file.name,
        sizeFormatted,
        url: objectUrl,
        type: file.type || "video/mp4",
      });
    };
  };

  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic("light");
    if (videoInfo?.url) {
      URL.revokeObjectURL(videoInfo.url);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    onSelectVideo(null);
  };

  return (
    <div
      id="video-picker-container"
      className="bg-zinc-900/50 rounded-3xl p-5 sm:p-6 border border-zinc-800 shadow-sm transition-all flex flex-col gap-4"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-zinc-800 text-zinc-300">
            <Film className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-zinc-500">
              Video Input
            </h2>
            <p className="text-xs font-medium text-zinc-300">Select clip from phone gallery</p>
          </div>
        </div>
        {videoInfo && (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400 bg-emerald-950/40 px-3 py-1 rounded-full border border-emerald-800/40">
            <CheckCircle2 className="w-3.5 h-3.5" /> Video Ready
          </span>
        )}
      </div>

      <input
        ref={fileInputRef}
        id="video-file-input"
        type="file"
        accept="video/mp4,video/quicktime,video/mov,video/webm,video/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {videoInfo ? (
        /* Selected Video Card with video preview */
        <div
          id="selected-video-card"
          className="relative overflow-hidden rounded-2xl bg-zinc-950 border border-zinc-800 p-4 flex flex-col gap-3 group"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-blue-400 shrink-0">
                <Video className="w-6 h-6" />
              </div>
              <div className="min-w-0">
                <p
                  id="selected-video-name"
                  className="text-sm font-semibold text-white truncate max-w-[220px] sm:max-w-xs"
                  title={videoInfo.name}
                >
                  {videoInfo.name}
                </p>
                <div className="flex items-center gap-2 text-xs text-zinc-400 mt-1">
                  <span className="bg-zinc-900 px-2 py-0.5 rounded text-[11px] font-mono text-zinc-300 border border-zinc-800">
                    {videoInfo.sizeFormatted}
                  </span>
                  {videoInfo.durationFormatted && (
                    <span className="bg-zinc-900 px-2 py-0.5 rounded text-[11px] font-mono text-zinc-300 border border-zinc-800">
                      ⏱ {videoInfo.durationFormatted}
                    </span>
                  )}
                  <span className="text-emerald-400 text-[11px] font-medium">
                    Attached
                  </span>
                </div>
              </div>
            </div>

            <button
              id="remove-video-btn"
              onClick={handleRemove}
              title="Remove video"
              className="p-2 rounded-lg bg-zinc-900 hover:bg-red-950/40 hover:text-red-400 text-zinc-400 transition-colors border border-zinc-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Video Preview Player if local URL is available */}
          {videoInfo.url ? (
            <div className="rounded-xl overflow-hidden bg-black border border-zinc-800 max-h-48 relative flex items-center justify-center">
              <video
                src={videoInfo.url}
                controls
                playsInline
                className="w-full max-h-48 object-contain rounded-xl"
              />
            </div>
          ) : (
            <div className="rounded-xl bg-zinc-900 border border-zinc-800 px-3.5 py-2.5 text-xs text-zinc-400 flex items-center gap-2">
              <Film className="w-4 h-4 text-blue-400" />
              <span>
                Video registered: <strong className="text-zinc-200">{videoInfo.name}</strong>. Gemini will tailor viral hooks, hashtags, and title to this clip.
              </span>
            </div>
          )}

          <div className="flex items-center justify-between text-xs pt-2 border-t border-zinc-800">
            <button
              id="change-video-btn"
              onClick={() => fileInputRef.current?.click()}
              className="text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 hover:underline"
            >
              <Upload className="w-3.5 h-3.5" /> Change Video
            </button>
            <span className="text-zinc-500 text-[11px]">
              Ready for AI Caption Engine
            </span>
          </div>
        </div>
      ) : (
        /* Upload Action Box */
        <div
          id="video-dropzone"
          className="border-2 border-dashed border-zinc-700 rounded-2xl p-6 sm:p-8 flex flex-col items-center justify-center gap-4 bg-zinc-900/60 hover:bg-zinc-850/80 transition-all group"
        >
          <div className="p-3.5 bg-zinc-800 rounded-full text-zinc-400 group-hover:text-blue-400 transition-colors">
            <Upload className="w-6 h-6" />
          </div>
          <div className="text-center px-4 max-w-sm">
            <p className="text-sm font-semibold text-zinc-200">
              Add your video clip
            </p>
            <p className="text-xs text-zinc-500 mt-1">
              Supports MP4, MOV, WebM videos from phone camera or gallery
            </p>
          </div>
          <button
            id="select-from-gallery-btn"
            type="button"
            onClick={() => {
              triggerHaptic("medium");
              fileInputRef.current?.click();
            }}
            className="px-5 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 border border-zinc-700 shadow-sm active:scale-95 transition-all"
          >
            <Upload className="w-4 h-4 text-blue-400" />
            <span>Select from gallery</span>
          </button>
        </div>
      )}
    </div>
  );
};


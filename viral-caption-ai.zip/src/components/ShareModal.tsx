import React, { useState } from "react";
import {
  Share2,
  X,
  Copy,
  Check,
  Send,
  MessageCircle,
  Twitter,
  Globe,
  CheckCircle2,
} from "lucide-react";
import { CaptionResult } from "../types";
import { triggerHaptic } from "../utils/storage";

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: CaptionResult | null;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  result,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !result) return null;

  const fullText = `${result.title}\n\n${result.caption}\n\n${result.hashtags.join(" ")}`;

  const handleNativeShare = async () => {
    triggerHaptic("medium");
    if (navigator.share) {
      try {
        await navigator.share({
          title: result.title,
          text: fullText,
        });
        onClose();
        return;
      } catch (err) {
        // User cancelled or error
      }
    }
    // Fallback to clipboard
    handleCopy();
  };

  const handleCopy = () => {
    triggerHaptic("light");
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsApp = () => {
    triggerHaptic("light");
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(fullText)}`;
    window.open(url, "_blank");
  };

  const handleTwitter = () => {
    triggerHaptic("light");
    const tweet = `${result.title}\n\n${result.hashtags.slice(0, 4).join(" ")}`;
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(tweet)}`;
    window.open(url, "_blank");
  };

  const handleTelegram = () => {
    triggerHaptic("light");
    const url = `https://t.me/share/url?url=&text=${encodeURIComponent(fullText)}`;
    window.open(url, "_blank");
  };

  return (
    <div
      id="share-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in"
      onClick={onClose}
    >
      <div
        id="share-modal-sheet"
        className="w-full sm:max-w-md bg-zinc-900 border border-zinc-800 rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl flex flex-col gap-4 max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Android bottom sheet pill handle */}
        <div className="w-12 h-1 bg-zinc-700 rounded-full mx-auto sm:hidden -mt-2" />

        {/* Modal Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-zinc-800 text-zinc-300">
              <Share2 className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Share Caption
              </h3>
              <p className="text-xs text-zinc-400">
                Post caption to your favorite social apps
              </p>
            </div>
          </div>

          <button
            id="close-share-modal-btn"
            onClick={onClose}
            className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Caption Preview snippet */}
        <div className="bg-zinc-950 rounded-2xl p-4 border border-zinc-800 text-xs">
          <p className="font-semibold text-white mb-1.5">{result.title}</p>
          <p className="text-zinc-400 line-clamp-2 text-xs mb-2 leading-relaxed">
            {result.caption}
          </p>
          <p className="text-zinc-500 font-mono text-[11px] truncate">
            {result.hashtags.join(" ")}
          </p>
        </div>

        {/* Share Options Grid */}
        <div className="grid grid-cols-4 gap-2.5 pt-1">
          {/* Native Android Share */}
          <button
            id="share-native-btn"
            onClick={handleNativeShare}
            className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-zinc-950 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 text-zinc-300 transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md">
              <Share2 className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-semibold">Share Menu</span>
          </button>

          {/* WhatsApp */}
          <button
            id="share-whatsapp-btn"
            onClick={handleWhatsApp}
            className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-zinc-950 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 text-zinc-300 transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
              <MessageCircle className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-semibold">WhatsApp</span>
          </button>

          {/* Twitter / X */}
          <button
            id="share-twitter-btn"
            onClick={handleTwitter}
            className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-zinc-950 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 text-zinc-300 transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-md">
              <Twitter className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-semibold">X / Twitter</span>
          </button>

          {/* Telegram */}
          <button
            id="share-telegram-btn"
            onClick={handleTelegram}
            className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-zinc-950 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 text-zinc-300 transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-500 text-white flex items-center justify-center shadow-md">
              <Send className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-semibold">Telegram</span>
          </button>
        </div>

        {/* Copy to Clipboard quick bar */}
        <button
          id="share-copy-clipboard-btn"
          onClick={handleCopy}
          className="w-full py-3.5 px-4 rounded-xl bg-zinc-950 hover:bg-zinc-850 border border-zinc-800 text-zinc-200 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
        >
          {copied ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400 font-bold">
                Copied Full Content to Clipboard!
              </span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 text-zinc-400" />
              <span>Copy Everything to Clipboard</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

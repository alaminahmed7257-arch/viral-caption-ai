import React, { useState } from "react";
import {
  History,
  Trash2,
  Copy,
  Check,
  Search,
  RotateCcw,
  Video,
  AlertTriangle,
  FileText,
  Share2,
  ExternalLink,
} from "lucide-react";
import { CaptionResult } from "../types";
import { triggerHaptic } from "../utils/storage";

interface HistorySectionProps {
  history: CaptionResult[];
  onDelete: (id: string) => void;
  onClearAll: () => void;
  onRestore: (item: CaptionResult) => void;
  onShareItem: (item: CaptionResult) => void;
}

export const HistorySection: React.FC<HistorySectionProps> = ({
  history,
  onDelete,
  onClearAll,
  onRestore,
  onShareItem,
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [copiedItemId, setCopiedItemId] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const filteredHistory = history.filter((item) => {
    const q = searchTerm.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.caption.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      (item.videoName && item.videoName.toLowerCase().includes(q)) ||
      item.hashtags.some((t) => t.toLowerCase().includes(q))
    );
  });

  const handleCopyBundle = (item: CaptionResult) => {
    triggerHaptic("light");
    const fullText = `${item.title}\n\n${item.caption}\n\n${item.hashtags.join(" ")}`;
    navigator.clipboard.writeText(fullText);
    setCopiedItemId(item.id);
    setTimeout(() => {
      setCopiedItemId(null);
    }, 2000);
  };

  const formatDate = (timestamp: number) => {
    try {
      const date = new Date(timestamp);
      return date.toLocaleDateString([], {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "Saved";
    }
  };

  return (
    <div
      id="history-section-container"
      className="bg-zinc-900/30 rounded-3xl p-5 sm:p-6 border border-zinc-800/50 shadow-sm flex flex-col gap-4"
    >
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-zinc-800 text-zinc-300">
            <History className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-zinc-500">
              Recent History
            </h2>
            <p className="text-xs font-medium text-zinc-300">{history.length} saved records</p>
          </div>
        </div>

        {history.length > 0 && (
          <div>
            {showClearConfirm ? (
              <div className="flex items-center gap-1.5 bg-zinc-900 p-1.5 rounded-xl border border-zinc-800">
                <button
                  id="confirm-clear-history-btn"
                  onClick={() => {
                    triggerHaptic("heavy");
                    onClearAll();
                    setShowClearConfirm(false);
                  }}
                  className="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold"
                >
                  Delete All
                </button>
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-2 py-1 text-zinc-400 hover:text-zinc-200 text-xs"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                id="clear-all-history-btn"
                onClick={() => {
                  triggerHaptic("light");
                  setShowClearConfirm(true);
                }}
                className="text-xs text-red-500 hover:underline font-medium flex items-center gap-1"
              >
                Clear All
              </button>
            )}
          </div>
        )}
      </div>

      {/* Search Filter */}
      {history.length > 0 && (
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3.5 top-3" />
          <input
            id="history-search-input"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search saved titles, captions, tags..."
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs text-zinc-200 placeholder-zinc-600 outline-none focus:border-blue-500"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              className="absolute right-3 top-2 text-xs text-zinc-500 hover:text-zinc-300"
            >
              Clear
            </button>
          )}
        </div>
      )}

      {/* History Items List */}
      {history.length === 0 ? (
        <div
          id="empty-history-state"
          className="text-center py-10 px-4 rounded-2xl bg-zinc-950 border border-dashed border-zinc-800 flex flex-col items-center gap-2"
        >
          <div className="w-10 h-10 rounded-full bg-zinc-850 flex items-center justify-center text-zinc-500">
            <History className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-zinc-300">No Saved Captions Yet</p>
          <p className="text-xs text-zinc-500 max-w-xs">
            Generate titles, captions, and hashtags in the Generator tab, then tap "Save" to keep them here.
          </p>
        </div>
      ) : filteredHistory.length === 0 ? (
        <div className="text-center py-6 text-xs text-zinc-500">
          No matches found for "{searchTerm}".
        </div>
      ) : (
        <div className="flex flex-col gap-3 max-h-[600px] overflow-y-auto pr-1">
          {filteredHistory.map((item) => (
            <div
              key={item.id}
              id={`history-item-${item.id}`}
              className="rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 p-4 flex flex-col gap-3 transition-all"
            >
              {/* Header: Date + Video name + Action icons */}
              <div className="flex items-center justify-between text-xs text-zinc-400 pb-2 border-b border-zinc-800">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-zinc-800 flex items-center justify-center text-zinc-400 shrink-0">
                    <Video className="w-4 h-4 text-blue-400" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-medium text-white truncate max-w-[150px] sm:max-w-xs">
                      {item.videoName || item.title}
                    </p>
                    <span className="font-mono text-[10px] text-zinc-500">
                      {formatDate(item.createdAt)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    id={`share-history-btn-${item.id}`}
                    onClick={() => onShareItem(item)}
                    title="Share this caption"
                    className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    id={`restore-history-btn-${item.id}`}
                    onClick={() => {
                      triggerHaptic("light");
                      onRestore(item);
                    }}
                    title="Load into Editor"
                    className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>

                  <button
                    id={`copy-history-btn-${item.id}`}
                    onClick={() => handleCopyBundle(item)}
                    title="Copy bundle"
                    className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
                  >
                    {copiedItemId === item.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  <button
                    id={`delete-history-btn-${item.id}`}
                    onClick={() => {
                      triggerHaptic("light");
                      onDelete(item.id);
                    }}
                    title="Delete saved item"
                    className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Title */}
              <div>
                <p className="text-xs font-semibold text-white">
                  {item.title}
                </p>
              </div>

              {/* Caption */}
              <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                <p className="text-xs text-zinc-300 line-clamp-3 leading-relaxed">
                  {item.caption}
                </p>
              </div>

              {/* Hashtags */}
              <div className="flex flex-wrap gap-1.5">
                {item.hashtags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-zinc-800 text-zinc-300 border border-zinc-700"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

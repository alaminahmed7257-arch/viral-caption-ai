import React, { useState } from "react";
import {
  Copy,
  Check,
  Bookmark,
  Share2,
  Sparkles,
  Hash,
  MessageSquareText,
  Heading,
  RefreshCw,
  Lightbulb,
  CheckCircle2,
} from "lucide-react";
import { CaptionResult } from "../types";
import { triggerHaptic } from "../utils/storage";

interface ResultSectionProps {
  result: CaptionResult | null;
  onUpdateResult: (updated: Partial<CaptionResult>) => void;
  onSave: () => void;
  onShare: () => void;
  onRegenerate: () => void;
  isGenerating: boolean;
  isSaved: boolean;
}

export const ResultSection: React.FC<ResultSectionProps> = ({
  result,
  onUpdateResult,
  onSave,
  onShare,
  onRegenerate,
  isGenerating,
  isSaved,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!result) return null;

  const handleCopyText = (text: string, key: string) => {
    triggerHaptic("light");
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => {
      setCopiedKey(null);
    }, 2000);
  };

  const handleCopyAll = () => {
    triggerHaptic("medium");
    const fullText = `${result.title}\n\n${result.caption}\n\n${result.hashtags.join(" ")}`;
    navigator.clipboard.writeText(fullText);
    setCopiedKey("all");
    setTimeout(() => {
      setCopiedKey(null);
    }, 2000);
  };

  const handleHashtagsTextChange = (raw: string) => {
    const splitTags = raw
      .split(/[\s,]+/)
      .map((t) => t.trim())
      .filter((t) => t.length > 0)
      .map((t) => (t.startsWith("#") ? t : `#${t}`));
    onUpdateResult({ hashtags: splitTags });
  };

  return (
    <div
      id="generated-results-container"
      className="bg-zinc-900 border border-zinc-800 rounded-3xl flex flex-col overflow-hidden shadow-xl transition-all"
    >
      {/* Header bar with Status & Actions */}
      <div className="p-5 sm:p-6 border-b border-zinc-800 flex flex-wrap items-center justify-between gap-3 bg-zinc-950/40">
        <h2 className="font-bold text-white flex items-center gap-2.5 text-base sm:text-lg">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Generated Results</span>
        </h2>

        <div className="flex items-center gap-2">
          <button
            id="copy-all-btn"
            onClick={handleCopyAll}
            className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-zinc-700"
          >
            {copiedKey === "all" ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-bold">Copied All</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-blue-400" />
                <span>Copy All</span>
              </>
            )}
          </button>

          <button
            id="share-button"
            type="button"
            onClick={() => {
              triggerHaptic("medium");
              onShare();
            }}
            className="px-3.5 sm:px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-xl text-xs sm:text-sm font-medium text-zinc-200 flex items-center gap-1.5 border border-zinc-700 transition-colors"
          >
            <Share2 className="w-3.5 h-3.5 text-zinc-300" />
            <span>Share</span>
          </button>

          <button
            id="save-button"
            type="button"
            onClick={() => {
              triggerHaptic("medium");
              onSave();
            }}
            className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all shadow-sm ${
              isSaved
                ? "bg-emerald-600 text-white"
                : "bg-white text-zinc-950 hover:bg-zinc-200"
            }`}
          >
            {isSaved ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Saved</span>
              </>
            ) : (
              <>
                <Bookmark className="w-3.5 h-3.5" />
                <span>Save Result</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Body with Suggested Title, Short Caption, Hashtags */}
      <div className="p-5 sm:p-6 space-y-6">
        {/* 1. Suggested Title */}
        <div id="editable-title-card" className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500 flex items-center gap-1.5">
              <Heading className="w-3.5 h-3.5 text-blue-400" />
              Suggested Title
            </h3>
            <button
              id="copy-title-btn"
              onClick={() => handleCopyText(result.title, "title")}
              className="text-blue-400 hover:text-blue-300 text-xs font-medium hover:underline flex items-center gap-1 transition-colors"
            >
              {copiedKey === "title" ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <span>Copy Title</span>
              )}
            </button>
          </div>

          <textarea
            id="editable-title-input"
            value={result.title}
            onChange={(e) => onUpdateResult({ title: e.target.value })}
            rows={2}
            className="w-full bg-zinc-950 border border-zinc-800 focus:border-blue-500 p-4 rounded-xl text-base sm:text-lg font-semibold text-white outline-none resize-none transition-colors"
          />

          {/* Hook alternatives if available */}
          {result.hookAlternatives && result.hookAlternatives.length > 0 && (
            <div className="pt-1 flex flex-col gap-1.5">
              <span className="text-xs font-medium text-zinc-500 flex items-center gap-1">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                Alternative Hook Ideas (tap to apply):
              </span>
              <div className="flex flex-col gap-1.5">
                {result.hookAlternatives.map((hook, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      triggerHaptic("light");
                      onUpdateResult({ title: hook });
                    }}
                    className="text-left text-xs text-zinc-300 hover:text-white bg-zinc-950 hover:bg-zinc-850 p-2.5 rounded-xl border border-zinc-850 hover:border-zinc-700 transition-colors truncate"
                  >
                    💡 {hook}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 2. Short Caption */}
        <div id="editable-caption-card" className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500 flex items-center gap-1.5">
              <MessageSquareText className="w-3.5 h-3.5 text-blue-400" />
              Short Caption
            </h3>
            <button
              id="copy-caption-btn"
              onClick={() => handleCopyText(result.caption, "caption")}
              className="text-blue-400 hover:text-blue-300 text-xs font-medium hover:underline flex items-center gap-1 transition-colors"
            >
              {copiedKey === "caption" ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <span>Copy Caption</span>
              )}
            </button>
          </div>

          <textarea
            id="editable-caption-input"
            value={result.caption}
            onChange={(e) => onUpdateResult({ caption: e.target.value })}
            rows={4}
            className="w-full bg-zinc-950 border border-zinc-800 focus:border-blue-500 p-4 rounded-xl text-sm leading-relaxed text-zinc-300 min-h-[110px] outline-none resize-none transition-colors"
          />
        </div>

        {/* 3. 10 Relevant Hashtags */}
        <div id="editable-hashtags-card" className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500 flex items-center gap-1.5">
              <Hash className="w-3.5 h-3.5 text-blue-400" />
              Hashtags ({result.hashtags.length} Tags)
            </h3>
            <button
              id="copy-hashtags-btn"
              onClick={() =>
                handleCopyText(result.hashtags.join(" "), "hashtags")
              }
              className="text-blue-400 hover:text-blue-300 text-xs font-medium hover:underline flex items-center gap-1 transition-colors"
            >
              {copiedKey === "hashtags" ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <span>Copy All Tags</span>
              )}
            </button>
          </div>

          {/* Hashtag Pills */}
          <div className="flex flex-wrap gap-2">
            {result.hashtags.map((tag, idx) => (
              <span
                key={idx}
                onClick={() => handleCopyText(tag, `tag-${idx}`)}
                title="Click to copy single hashtag"
                className="px-3 py-1.5 bg-zinc-800 border border-zinc-700 rounded-full text-xs font-medium text-zinc-300 hover:bg-zinc-700 hover:text-white transition-colors cursor-pointer flex items-center gap-1"
              >
                {tag}
                {copiedKey === `tag-${idx}` && (
                  <Check className="w-3 h-3 text-emerald-400" />
                )}
              </span>
            ))}
          </div>

          {/* Raw Editable Hashtags textarea */}
          <textarea
            id="editable-hashtags-input"
            value={result.hashtags.join(" ")}
            onChange={(e) => handleHashtagsTextChange(e.target.value)}
            rows={2}
            placeholder="#tag1 #tag2 ..."
            className="w-full bg-zinc-950 border border-zinc-800 focus:border-blue-500 rounded-xl p-3.5 text-xs font-mono text-zinc-300 outline-none resize-none transition-colors"
          />
        </div>
      </div>
    </div>
  );
};

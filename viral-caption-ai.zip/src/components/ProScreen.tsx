import React, { useState } from "react";
import {
  Crown,
  Sparkles,
  Zap,
  ShieldCheck,
  Check,
  Flame,
  Star,
  Sliders,
  Layers,
  ArrowRight,
  Info,
} from "lucide-react";
import { DailyUsageInfo } from "../types";
import { triggerHaptic } from "../utils/storage";

interface ProScreenProps {
  dailyUsage: DailyUsageInfo;
  onOpenGenerator?: () => void;
  onShowToast: (message: string, type?: "info" | "success" | "error") => void;
}

export const ProScreen: React.FC<ProScreenProps> = ({
  dailyUsage,
  onOpenGenerator,
  onShowToast,
}) => {
  const [billingPeriod, setBillingPeriod] = useState<"monthly" | "yearly">("yearly");

  const handlePurchaseAttempt = () => {
    triggerHaptic("medium");
    onShowToast(
      "🚀 Pro Plan is Coming Soon! Google Play in-app billing is being prepared for the upcoming store release.",
      "info"
    );
  };

  return (
    <div id="pro-screen-container" className="flex flex-col gap-5 max-w-2xl mx-auto">
      {/* Hero Pro Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-500/20 via-purple-950/40 to-blue-950/50 border border-amber-500/30 p-6 sm:p-7 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-40 h-40 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-40 h-40 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold tracking-wide">
              <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              VIRAL CAPTION PRO
            </span>
            <span className="text-[11px] font-semibold text-zinc-400 bg-zinc-900/80 px-2.5 py-0.5 rounded-full border border-zinc-800">
              Future Google Play Release
            </span>
          </div>

          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Scale Your Views With Unlimited AI Power
            </h2>
            <p className="text-xs sm:text-sm text-zinc-300 mt-1 leading-relaxed">
              Unlock unrestricted daily viral generations, platform-tuned algorithm hooks, and an ad-free creation experience.
            </p>
          </div>

          {/* Current Status Badge */}
          <div className="p-3.5 rounded-2xl bg-zinc-900/90 border border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-zinc-800 flex items-center justify-center text-zinc-400 font-bold text-xs">
                Free
              </div>
              <div>
                <p className="text-xs font-semibold text-white">Your Current Plan: Free Tier</p>
                <p className="text-[11px] text-zinc-400">
                  {dailyUsage.remaining} of {dailyUsage.maxDaily} daily generations remaining today
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
                Reset: 24h
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Core Pro Features Grid */}
      <div className="flex flex-col gap-3">
        <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-500 px-1">
          Everything Included in Pro
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Feature 1: Unlimited AI generations */}
          <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800/90 flex items-start gap-3.5 hover:border-zinc-700 transition-colors">
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center shrink-0 text-blue-400">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                Unlimited AI Generations
                <span className="px-1.5 py-0.2 text-[9px] bg-blue-500/20 text-blue-300 font-bold rounded">No Limit</span>
              </h4>
              <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                Generate infinite titles, short-form captions, and hashtag bundles anytime without waiting for 24-hour daily resets.
              </p>
            </div>
          </div>

          {/* Feature 2: No Advertisements */}
          <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800/90 flex items-start gap-3.5 hover:border-zinc-700 transition-colors">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center shrink-0 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                100% Ad-Free Experience
                <span className="px-1.5 py-0.2 text-[9px] bg-emerald-500/20 text-emerald-300 font-bold rounded">Clean</span>
              </h4>
              <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                Enjoy a distraction-free creator studio with zero banner ads, interstitials, or promotional popups.
              </p>
            </div>
          </div>

          {/* Feature 3: Advanced Title Styles */}
          <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800/90 flex items-start gap-3.5 hover:border-zinc-700 transition-colors">
            <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center shrink-0 text-purple-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                Advanced Title & Hook Styles
                <span className="px-1.5 py-0.2 text-[9px] bg-purple-500/20 text-purple-300 font-bold rounded">High CTR</span>
              </h4>
              <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                Access premium psychological click-triggers, suspense hooks, and multi-alternative headline variations.
              </p>
            </div>
          </div>

          {/* Feature 4: Platform-Specific Optimization */}
          <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800/90 flex items-start gap-3.5 hover:border-zinc-700 transition-colors">
            <div className="w-9 h-9 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0 text-rose-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                Platform-Specific Optimization
                <span className="px-1.5 py-0.2 text-[9px] bg-rose-500/20 text-rose-300 font-bold rounded">Algorithm Tuned</span>
              </h4>
              <p className="text-[11px] text-zinc-400 mt-1 leading-normal">
                Dedicated algorithmic tuning for TikTok FYP, Instagram Reels, YouTube Shorts, and Facebook Watch feeds.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Plan Comparison Table */}
      <div className="p-4 sm:p-5 rounded-3xl bg-zinc-900/70 border border-zinc-800/90 flex flex-col gap-3">
        <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-400">
          Plan Comparison
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-400">
                <th className="pb-2.5 font-semibold">Feature</th>
                <th className="pb-2.5 font-semibold text-center w-24">Free Tier</th>
                <th className="pb-2.5 font-semibold text-center w-28 text-amber-400">Pro Tier</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
              <tr>
                <td className="py-2.5 font-medium">Daily Generations</td>
                <td className="py-2.5 text-center text-zinc-400">5 / day</td>
                <td className="py-2.5 text-center font-bold text-emerald-400">Unlimited</td>
              </tr>
              <tr>
                <td className="py-2.5 font-medium">Ad-Free Experience</td>
                <td className="py-2.5 text-center text-zinc-500">No</td>
                <td className="py-2.5 text-center font-bold text-emerald-400">Yes (100% Ad-Free)</td>
              </tr>
              <tr>
                <td className="py-2.5 font-medium">Platform Targeting</td>
                <td className="py-2.5 text-center text-zinc-400">Standard</td>
                <td className="py-2.5 text-center font-bold text-amber-400">Advanced AI Tuning</td>
              </tr>
              <tr>
                <td className="py-2.5 font-medium">Custom Hook Variations</td>
                <td className="py-2.5 text-center text-zinc-400">3 Hooks</td>
                <td className="py-2.5 text-center font-bold text-amber-400">Extended Viral Hooks</td>
              </tr>
              <tr>
                <td className="py-2.5 font-medium">Local History Storage</td>
                <td className="py-2.5 text-center text-zinc-400">Included</td>
                <td className="py-2.5 text-center font-bold text-emerald-400">Unlimited Saved Items</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Pricing Selector & Purchase Action */}
      <div className="p-5 sm:p-6 rounded-3xl bg-zinc-900 border border-amber-500/30 flex flex-col gap-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-bold text-white">Choose Your Billing</h4>
            <p className="text-xs text-zinc-400">Cancel anytime on Google Play</p>
          </div>

          <div className="flex bg-zinc-950 p-1 rounded-xl border border-zinc-800 text-xs">
            <button
              onClick={() => {
                triggerHaptic("light");
                setBillingPeriod("monthly");
              }}
              className={`px-3 py-1 rounded-lg font-medium transition-all ${
                billingPeriod === "monthly"
                  ? "bg-zinc-800 text-white shadow-sm"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => {
                triggerHaptic("light");
                setBillingPeriod("yearly");
              }}
              className={`px-3 py-1 rounded-lg font-medium transition-all flex items-center gap-1 ${
                billingPeriod === "yearly"
                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-sm"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              Yearly <span className="text-[10px] text-emerald-400 font-bold">-50%</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div
            onClick={() => setBillingPeriod("yearly")}
            className={`p-4 rounded-2xl border cursor-pointer transition-all ${
              billingPeriod === "yearly"
                ? "bg-amber-500/10 border-amber-500/60 ring-1 ring-amber-500/40"
                : "bg-zinc-950/60 border-zinc-800 hover:border-zinc-700"
            }`}
          >
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                  Best Value
                </span>
                <h5 className="text-base font-bold text-white mt-0.5">$29.99 / year</h5>
                <p className="text-[11px] text-zinc-400">Just $2.49 / month, billed annually</p>
              </div>
              <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${billingPeriod === "yearly" ? "border-amber-400 bg-amber-400 text-zinc-950" : "border-zinc-700"}`}>
                {billingPeriod === "yearly" && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
            </div>
          </div>

          <div
            onClick={() => setBillingPeriod("monthly")}
            className={`p-4 rounded-2xl border cursor-pointer transition-all ${
              billingPeriod === "monthly"
                ? "bg-amber-500/10 border-amber-500/60 ring-1 ring-amber-500/40"
                : "bg-zinc-950/60 border-zinc-800 hover:border-zinc-700"
            }`}
          >
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                  Flexible
                </span>
                <h5 className="text-base font-bold text-white mt-0.5">$4.99 / month</h5>
                <p className="text-[11px] text-zinc-400">Standard monthly subscription</p>
              </div>
              <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${billingPeriod === "monthly" ? "border-amber-400 bg-amber-400 text-zinc-950" : "border-zinc-700"}`}>
                {billingPeriod === "monthly" && <Check className="w-3.5 h-3.5 stroke-[3]" />}
              </div>
            </div>
          </div>
        </div>

        {/* Clear Coming Soon Purchase Action Button */}
        <div className="flex flex-col gap-2 pt-2">
          <button
            id="go-pro-purchase-btn"
            type="button"
            onClick={handlePurchaseAttempt}
            className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-zinc-950 font-bold text-sm shadow-lg shadow-amber-950/30 flex items-center justify-center gap-2 transition-all cursor-pointer group"
          >
            <Crown className="w-4 h-4 fill-zinc-950" />
            <span>Upgrade to Pro</span>
            <span className="px-2 py-0.5 rounded-full bg-zinc-950/20 text-zinc-950 text-[10px] font-extrabold tracking-wider border border-zinc-950/30">
              COMING SOON
            </span>
          </button>

          <div className="flex items-center justify-center gap-1.5 text-[11px] text-zinc-400 text-center">
            <Info className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
            <span>Google Play In-App Billing will activate in the next release. No charges today.</span>
          </div>
        </div>
      </div>
    </div>
  );
};

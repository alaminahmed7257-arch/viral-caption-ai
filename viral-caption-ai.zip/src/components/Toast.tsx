import React from "react";
import { CheckCircle2, AlertCircle, Info, X } from "lucide-react";

export interface ToastMessage {
  id: string;
  type: "success" | "error" | "info";
  text: string;
}

interface ToastProps {
  toast: ToastMessage | null;
  onDismiss: () => void;
}

export const Toast: React.FC<ToastProps> = ({ toast, onDismiss }) => {
  if (!toast) return null;

  const bgStyles =
    toast.type === "success"
      ? "bg-zinc-900 border-zinc-700 text-zinc-100"
      : toast.type === "error"
      ? "bg-zinc-900 border-red-800 text-red-200"
      : "bg-zinc-900 border-zinc-700 text-zinc-100";

  return (
    <div
      id="android-toast-snackbar"
      className="fixed bottom-16 sm:bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 w-full max-w-sm"
    >
      <div
        className={`flex items-center justify-between gap-3 px-4 py-3 rounded-2xl border shadow-2xl backdrop-blur-md animate-in slide-in-from-bottom-3 duration-200 ${bgStyles}`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          {toast.type === "success" && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
          {toast.type === "error" && <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
          {toast.type === "info" && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
          <span className="text-xs font-semibold truncate">{toast.text}</span>
        </div>
        <button
          onClick={onDismiss}
          className="p-1 rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};

import React from "react";
import { BookOpen, ArrowRight } from "lucide-react";
import { triggerHaptic } from "../utils/storage";

interface PresetsModalProps {
  onSelectPreset: (description: string) => void;
}

interface PresetItem {
  id: string;
  category: string;
  description: string;
  icon: string;
  badge: string;
}

const PRESETS: PresetItem[] = [
  {
    id: "p1",
    category: "Tech & Phone Tips",
    icon: "📱",
    badge: "Trending",
    description: "3 hidden camera settings on phone that make videos look like a $4,000 cinema camera.",
  },
  {
    id: "p2",
    category: "Food & Recipes",
    icon: "🍜",
    badge: "Viral Food",
    description: "Ultra quick 5-minute midnight garlic butter noodles cooked in one pot with chili crunch oil and runny egg yolk.",
  },
  {
    id: "p3",
    category: "Fitness & Transformation",
    icon: "💪",
    badge: "High Retention",
    description: "My daily 10-minute calisthenics routine that gave me abs without setting foot in a gym or counting calories.",
  },
  {
    id: "p4",
    category: "Travel & Adventure",
    icon: "✈️",
    badge: "Aesthetic",
    description: "Secret rooftop pagoda view in Kyoto at sunset that no tourists know about. Golden hour aesthetic with lo-fi beats.",
  },
  {
    id: "p5",
    category: "Comedy & Storytime",
    icon: "😂",
    badge: "High Engagement",
    description: "POV: Storytime about the most awkward first date of my life where he brought his mom to dinner unexpectedly.",
  },
  {
    id: "p6",
    category: "Product / Setup Review",
    icon: "💼",
    badge: "Sales & Leads",
    description: "Top 3 aesthetic productivity desk setup gadgets under $30 on Amazon that save 5 hours every work week.",
  },
];

export const PresetsModal: React.FC<PresetsModalProps> = ({ onSelectPreset }) => {
  return (
    <div
      id="presets-section-container"
      className="bg-zinc-900/40 rounded-3xl p-5 sm:p-6 border border-zinc-800 shadow-sm flex flex-col gap-4"
    >
      <div className="flex items-center gap-2.5 pb-2 border-b border-zinc-800">
        <div className="p-2 rounded-xl bg-zinc-800 text-zinc-300">
          <BookOpen className="w-4 h-4 text-blue-400" />
        </div>
        <div>
          <h2 className="text-xs font-semibold uppercase tracking-widest text-zinc-500">
            Video Prompt Templates
          </h2>
          <p className="text-xs font-medium text-zinc-300">
            Tap any template to load it into the description
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {PRESETS.map((item) => (
          <div
            key={item.id}
            id={`preset-card-${item.id}`}
            onClick={() => {
              triggerHaptic("medium");
              onSelectPreset(item.description);
            }}
            className="p-4 rounded-2xl bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 cursor-pointer transition-all flex flex-col justify-between gap-2.5 group shadow-sm"
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                  <span className="text-sm">{item.icon}</span>
                  {item.category}
                </span>
                <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700">
                  {item.badge}
                </span>
              </div>
              <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                {item.description}
              </p>
            </div>

            <div className="flex items-center justify-between text-xs pt-2 border-t border-zinc-800/80 text-zinc-500 group-hover:text-blue-400 transition-colors">
              <span className="text-zinc-500 text-[11px]">Load template</span>
              <span className="font-medium flex items-center gap-1 text-xs">
                Use <ArrowRight className="w-3 h-3" />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};


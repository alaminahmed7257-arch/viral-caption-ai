import React from "react";
import { Wand2, History, BookOpen, Crown } from "lucide-react";
import { AppTab } from "../types";
import { triggerHaptic } from "../utils/storage";

interface AndroidNavBarProps {
  currentTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  historyCount: number;
}

export const AndroidNavBar: React.FC<AndroidNavBarProps> = ({
  currentTab,
  onSelectTab,
  historyCount,
}) => {
  return (
    <div
      id="android-bottom-nav"
      className="w-full bg-zinc-950/95 backdrop-blur-md border-t border-zinc-850 px-4 pt-2 pb-3 flex flex-col gap-2 z-20"
    >
      <div className="flex items-center justify-around">
        {/* Generator Tab */}
        <button
          id="bottom-nav-generator"
          onClick={() => {
            triggerHaptic("light");
            onSelectTab("generator");
          }}
          className={`flex flex-col items-center gap-1 transition-all ${
            currentTab === "generator"
              ? "text-white font-medium"
              : "text-zinc-500 hover:text-zinc-300"
          }`}
        >
          <div
            className={`w-10 h-7 rounded-xl flex items-center justify-center transition-all ${
              currentTab === "generator"
                ? "bg-zinc-800 text-white"
                : "bg-transparent text-zinc-500"
            }`}
          >
            <Wand2 className="w-4 h-4" />
          </div>
          <span className="text-[10px] tracking-tight">AI Generator</span>
        </button>

        {/* History Tab */}
        <button
          id="bottom-nav-history"
          onClick={() => {
            triggerHaptic("light");
            onSelectTab("history");
          }}
          className={`flex flex-col items-center gap-1 transition-all relative ${
            currentTab === "history"
              ? "text-white font-medium"
              : "text-zinc-500 hover:text-zinc-300"
          }`}
        >
          <div
            className={`w-10 h-7 rounded-xl flex items-center justify-center transition-all relative ${
              currentTab === "history"
                ? "bg-zinc-800 text-white"
                : "bg-transparent text-zinc-500"
            }`}
          >
            <History className="w-4 h-4" />
            {historyCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-blue-600 text-white text-[9px] font-bold flex items-center justify-center">
                {historyCount > 9 ? "9+" : historyCount}
              </span>
            )}
          </div>
          <span className="text-[10px] tracking-tight">Saved History</span>
        </button>

        {/* Templates Tab */}
        <button
          id="bottom-nav-presets"
          onClick={() => {
            triggerHaptic("light");
            onSelectTab("presets");
          }}
          className={`flex flex-col items-center gap-1 transition-all ${
            currentTab === "presets"
              ? "text-white font-medium"
              : "text-zinc-500 hover:text-zinc-300"
          }`}
        >
          <div
            className={`w-10 h-7 rounded-xl flex items-center justify-center transition-all ${
              currentTab === "presets"
                ? "bg-zinc-800 text-white"
                : "bg-transparent text-zinc-500"
            }`}
          >
            <BookOpen className="w-4 h-4" />
          </div>
          <span className="text-[10px] tracking-tight">Templates</span>
        </button>

        {/* Pro Plan Tab */}
        <button
          id="bottom-nav-pro"
          onClick={() => {
            triggerHaptic("medium");
            onSelectTab("pro");
          }}
          className={`flex flex-col items-center gap-1 transition-all ${
            currentTab === "pro"
              ? "text-amber-400 font-bold"
              : "text-amber-500/70 hover:text-amber-400"
          }`}
        >
          <div
            className={`w-10 h-7 rounded-xl flex items-center justify-center transition-all ${
              currentTab === "pro"
                ? "bg-amber-500 text-zinc-950 shadow-md shadow-amber-950/40"
                : "bg-amber-500/10 text-amber-400 border border-amber-500/30"
            }`}
          >
            <Crown className="w-4 h-4 fill-current" />
          </div>
          <span className="text-[10px] tracking-tight flex items-center gap-0.5">
            Pro <span className="text-[8px] bg-amber-400/20 text-amber-300 px-0.5 rounded font-extrabold">SOON</span>
          </span>
        </button>
      </div>

      {/* Samsung Android Navigation Gesture Bar Indicator */}
      <div className="w-32 h-1 bg-zinc-800 rounded-full mx-auto" />
    </div>
  );
};

import React from "react";
import { Sparkles, History, Wand2, Smartphone, Monitor, BookOpen, Crown, Zap } from "lucide-react";
import { AppTab, DailyUsageInfo } from "../types";
import { triggerHaptic } from "../utils/storage";

interface AndroidHeaderProps {
  currentTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  historyCount: number;
  dailyUsage: DailyUsageInfo;
  isGalaxyFrame: boolean;
  onToggleFrame: () => void;
}

export const AndroidHeader: React.FC<AndroidHeaderProps> = ({
  currentTab,
  onSelectTab,
  historyCount,
  dailyUsage,
  isGalaxyFrame,
  onToggleFrame,
}) => {
  return (
    <header className="w-full bg-zinc-950 border-b border-zinc-800 sticky top-0 z-20 shadow-sm">
      {/* Top action row */}
      <div className="px-4 sm:px-5 pt-3.5 pb-2.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="w-9 h-9 sm:w-10 sm:h-10 bg-gradient-to-tr from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-900/20 text-white shrink-0">
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <h1 id="app-title" className="text-sm sm:text-base font-bold tracking-tight text-white truncate">
                Viral Caption AI
              </h1>
              <span className="px-1.5 py-0.2 text-[9px] font-semibold rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700 shrink-0">
                Gemini
              </span>
            </div>
            <p className="text-[10px] sm:text-[11px] text-zinc-500 font-medium truncate">
              Clean Minimalist Content Studio
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Go Pro Header Button */}
          <button
            id="header-go-pro-btn"
            onClick={() => {
              triggerHaptic("medium");
              onSelectTab("pro");
            }}
            className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              currentTab === "pro"
                ? "bg-gradient-to-r from-amber-400 to-orange-500 text-zinc-950 shadow-md shadow-amber-950/40"
                : "bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 text-amber-300 border border-amber-500/40"
            }`}
          >
            <Crown className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="hidden xs:inline">Go Pro</span>
            <span className="text-[9px] bg-amber-400/20 text-amber-200 px-1 py-0.2 rounded font-extrabold">
              SOON
            </span>
          </button>

          {/* Toggle Device Frame View */}
          <button
            id="toggle-galaxy-frame-btn"
            onClick={() => {
              triggerHaptic("light");
              onToggleFrame();
            }}
            title={isGalaxyFrame ? "Switch to Wide View" : "Switch to Galaxy View"}
            className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-medium flex items-center gap-1.5 transition-colors border border-zinc-800"
          >
            {isGalaxyFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-blue-400" />
                <span className="hidden md:inline">Wide</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                <span className="hidden md:inline">Galaxy</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Daily Free Generation Limit Status Bar */}
      <div className="px-4 sm:px-5 py-1.5 bg-zinc-900/60 border-t border-zinc-800/80 flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 text-zinc-400">
            <Zap className="w-3 h-3 text-blue-400" />
            <span>Free Plan:</span>
          </span>
          <span
            id="header-daily-remaining-count"
            className={`font-bold px-1.5 py-0.2 rounded ${
              dailyUsage.remaining === 0
                ? "bg-rose-500/20 text-rose-300"
                : dailyUsage.remaining <= 2
                ? "bg-amber-500/20 text-amber-300"
                : "bg-blue-500/20 text-blue-300"
            }`}
          >
            {dailyUsage.remaining} / {dailyUsage.maxDaily} daily left
          </span>
        </div>

        <button
          onClick={() => {
            triggerHaptic("light");
            onSelectTab("pro");
          }}
          className="text-[10px] text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
        >
          <span>Need Unlimited?</span>
          <span className="underline">Get Pro</span>
        </button>
      </div>

      {/* Navigation Tabs */}
      <nav id="main-navigation-tabs" className="px-4 pb-2.5 pt-2 flex items-center gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar">
        <button
          id="tab-generator-btn"
          onClick={() => {
            triggerHaptic("light");
            onSelectTab("generator");
          }}
          className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            currentTab === "generator"
              ? "bg-zinc-800 text-white border border-zinc-700 shadow-sm"
              : "bg-zinc-900/50 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850 border border-zinc-800/80"
          }`}
        >
          <Wand2 className="w-3.5 h-3.5 text-blue-400" />
          <span>Generator</span>
        </button>

        <button
          id="tab-history-btn"
          onClick={() => {
            triggerHaptic("light");
            onSelectTab("history");
          }}
          className={`flex-1 min-w-[85px] py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all relative ${
            currentTab === "history"
              ? "bg-zinc-800 text-white border border-zinc-700 shadow-sm"
              : "bg-zinc-900/50 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850 border border-zinc-800/80"
          }`}
        >
          <History className="w-3.5 h-3.5 text-zinc-400" />
          <span>History</span>
          {historyCount > 0 && (
            <span
              id="history-badge-count"
              className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${
                currentTab === "history"
                  ? "bg-blue-600 text-white"
                  : "bg-zinc-800 text-zinc-300 border border-zinc-700"
              }`}
            >
              {historyCount}
            </span>
          )}
        </button>

        <button
          id="tab-presets-btn"
          onClick={() => {
            triggerHaptic("light");
            onSelectTab("presets");
          }}
          className={`py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            currentTab === "presets"
              ? "bg-zinc-800 text-white border border-zinc-700 shadow-sm"
              : "bg-zinc-900/50 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850 border border-zinc-800/80"
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-zinc-400" />
          <span>Templates</span>
        </button>

        <button
          id="tab-pro-btn"
          onClick={() => {
            triggerHaptic("medium");
            onSelectTab("pro");
          }}
          className={`py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
            currentTab === "pro"
              ? "bg-gradient-to-r from-amber-500 to-orange-500 text-zinc-950 font-bold shadow-sm"
              : "bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 border border-amber-500/30"
          }`}
        >
          <Crown className={`w-3.5 h-3.5 ${currentTab === "pro" ? "fill-zinc-950 text-zinc-950" : "fill-amber-400 text-amber-400"}`} />
          <span>Pro</span>
        </button>
      </nav>
    </header>
  );
};

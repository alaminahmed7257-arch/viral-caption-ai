import React from "react";
import {
  FileText,
  Sparkles,
  Zap,
  Flame,
  Smile,
  GraduationCap,
  Heart,
  AlertCircle,
  HelpCircle,
} from "lucide-react";
import { ToneOption, DailyUsageInfo } from "../types";
import { triggerHaptic } from "../utils/storage";

interface DescriptionSectionProps {
  description: string;
  onChangeDescription: (val: string) => void;
  tone: ToneOption;
  onChangeTone: (tone: ToneOption) => void;
  targetPlatform: string;
  onChangeTargetPlatform: (platform: string) => void;
  onGenerate: () => void;
  isGenerating: boolean;
  hasVideoSelected: boolean;
  dailyUsage?: DailyUsageInfo;
  onOpenPro?: () => void;
}

const TONE_OPTIONS: { id: ToneOption; label: string; icon: React.ReactNode }[] = [
  { id: "viral", label: "Viral 🔥", icon: <Flame className="w-3.5 h-3.5 text-amber-400" /> },
  { id: "humorous", label: "Funny 😂", icon: <Smile className="w-3.5 h-3.5 text-yellow-400" /> },
  { id: "educational", label: "Tips & How-To 💡", icon: <GraduationCap className="w-3.5 h-3.5 text-cyan-400" /> },
  { id: "dramatic", label: "Dramatic ⚡", icon: <Zap className="w-3.5 h-3.5 text-violet-400" /> },
  { id: "inspiring", label: "Inspiring ✨", icon: <Heart className="w-3.5 h-3.5 text-rose-400" /> },
];

interface PlatformOption {
  id: string;
  name: string;
  badge: string;
  icon: string;
  accentColor: string;
}

const PLATFORM_OPTIONS: PlatformOption[] = [
  {
    id: "TikTok",
    name: "TikTok",
    badge: "FYP & Viral Hook",
    icon: "🎵",
    accentColor: "border-pink-500/60 text-pink-400",
  },
  {
    id: "Instagram",
    name: "Instagram",
    badge: "Reels & Aesthetic",
    icon: "📸",
    accentColor: "border-purple-500/60 text-purple-400",
  },
  {
    id: "YouTube",
    name: "YouTube",
    badge: "High CTR #Shorts",
    icon: "▶️",
    accentColor: "border-red-500/60 text-red-400",
  },
  {
    id: "Facebook",
    name: "Facebook",
    badge: "Watch & Viral Shares",
    icon: "👥",
    accentColor: "border-blue-500/60 text-blue-400",
  },
];

const QUICK_TAG_SUGGESTIONS = [
  "Wait till the end...",
  "POV: when you realize...",
  "3 mistakes to avoid...",
  "Secret trick nobody knows...",
  "Step-by-step tutorial for beginners...",
];

export const DescriptionSection: React.FC<DescriptionSectionProps> = ({
  description,
  onChangeDescription,
  tone,
  onChangeTone,
  targetPlatform,
  onChangeTargetPlatform,
  onGenerate,
  isGenerating,
  hasVideoSelected,
  dailyUsage,
  onOpenPro,
}) => {
  const handleQuickAdd = (text: string) => {
    triggerHaptic("light");
    if (!description.trim()) {
      onChangeDescription(text);
    } else {
      onChangeDescription(`${description.trim()} ${text}`);
    }
  };

  const isLimitReached = dailyUsage ? dailyUsage.remaining <= 0 : false;

  return (
    <div
      id="description-section-container"
      className="bg-zinc-900/50 rounded-3xl p-5 sm:p-6 border border-zinc-800 shadow-sm flex flex-col gap-4"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-zinc-800 text-zinc-300">
            <FileText className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-zinc-500">
              Video Context
            </h2>
            <p className="text-xs font-medium text-zinc-300">Describe what's happening</p>
          </div>
        </div>

        {/* Daily limit badge */}
        {dailyUsage ? (
          <button
            id="daily-limit-badge-btn"
            type="button"
            onClick={() => {
              if (onOpenPro) {
                triggerHaptic("light");
                onOpenPro();
              }
            }}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold flex items-center gap-1.5 transition-all border ${
              isLimitReached
                ? "bg-rose-500/10 border-rose-500/40 text-rose-300 hover:bg-rose-500/20"
                : dailyUsage.remaining <= 2
                ? "bg-amber-500/10 border-amber-500/40 text-amber-300 hover:bg-amber-500/20"
                : "bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700"
            }`}
          >
            <Zap className={`w-3 h-3 ${isLimitReached ? "text-rose-400" : "text-blue-400"}`} />
            <span>{dailyUsage.remaining}/{dailyUsage.maxDaily} left today</span>
          </button>
        ) : (
          <span className="text-xs font-mono text-zinc-500">
            {description.length} / 500
          </span>
        )}
      </div>

      {/* Description Textarea */}
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-medium text-zinc-400 ml-1">
          Describe the video context
        </label>
        <div className="relative">
          <textarea
            id="video-description-input"
            value={description}
            onChange={(e) => onChangeDescription(e.target.value)}
            placeholder="What is happening in this video? Gemini will use this to generate viral content."
            rows={3}
            maxLength={500}
            className="w-full bg-zinc-950 border border-zinc-800 focus:border-blue-500 rounded-xl p-4 text-sm text-zinc-200 placeholder-zinc-600 resize-none outline-none transition-all"
          />
          {description && (
            <button
              id="clear-description-btn"
              onClick={() => {
                triggerHaptic("light");
                onChangeDescription("");
              }}
              className="absolute top-3 right-3 px-2 py-0.5 rounded bg-zinc-800 text-[10px] text-zinc-400 hover:text-zinc-200 border border-zinc-700"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Quick Hook Suggestions */}
      <div className="flex flex-col gap-1.5">
        <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-blue-400" />
          Starter Hooks:
        </p>
        <div className="flex flex-wrap gap-1.5">
          {QUICK_TAG_SUGGESTIONS.map((hook, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleQuickAdd(hook)}
              className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 text-xs transition-colors border border-zinc-800 hover:border-zinc-700"
            >
              + {hook}
            </button>
          ))}
        </div>
      </div>

      {/* Platform Selection */}
      <div className="pt-2 border-t border-zinc-800 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider block">
            Target Platform:
          </label>
          <span className="text-[11px] text-blue-400 font-medium">
            AI optimizes hooks & hashtags for {targetPlatform}
          </span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {PLATFORM_OPTIONS.map((p) => {
            const isSelected =
              targetPlatform.toLowerCase().includes(p.id.toLowerCase()) ||
              (p.id === "TikTok" && targetPlatform === "TikTok") ||
              (p.id === "Instagram" && targetPlatform.includes("Instagram")) ||
              (p.id === "YouTube" && targetPlatform.includes("YouTube")) ||
              (p.id === "Facebook" && targetPlatform.includes("Facebook"));

            return (
              <button
                key={p.id}
                id={`platform-btn-${p.id.toLowerCase()}`}
                type="button"
                onClick={() => {
                  triggerHaptic("light");
                  onChangeTargetPlatform(p.id);
                }}
                className={`p-2.5 rounded-2xl text-left transition-all border flex flex-col gap-1 relative ${
                  isSelected
                    ? "bg-zinc-800 text-white border-blue-500 shadow-md shadow-blue-950/40 ring-1 ring-blue-500/40"
                    : "bg-zinc-950/70 text-zinc-400 hover:text-zinc-200 border-zinc-800/90 hover:border-zinc-700"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-base">{p.icon}</span>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                  )}
                </div>
                <div>
                  <span className="text-xs font-semibold block text-zinc-100">{p.name}</span>
                  <span className="text-[10px] text-zinc-500 line-clamp-1">{p.badge}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tone Selection Row */}
      <div className="pt-2 border-t border-zinc-800">
        <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2 block">
          Vibe / Tone:
        </label>
        <div className="flex flex-wrap gap-1.5">
          {TONE_OPTIONS.map((t) => (
            <button
              key={t.id}
              id={`tone-btn-${t.id}`}
              type="button"
              onClick={() => {
                triggerHaptic("light");
                onChangeTone(t.id);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all flex items-center gap-1.5 ${
                tone === t.id
                  ? "bg-zinc-800 text-white border border-zinc-600 shadow-sm"
                  : "bg-zinc-950 text-zinc-400 hover:text-zinc-200 border border-zinc-850"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Daily Limit Warning Banner when 0 remaining */}
      {isLimitReached && (
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <div className="text-xs">
              <p className="font-bold text-amber-300">Daily Free Limit Reached (0/5)</p>
              <p className="text-zinc-400 text-[11px]">Free generation resets every 24 hours. Check out Pro for unlimited.</p>
            </div>
          </div>
          {onOpenPro && (
            <button
              type="button"
              onClick={() => {
                triggerHaptic("medium");
                onOpenPro();
              }}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold shrink-0 flex items-center gap-1 shadow-sm cursor-pointer"
            >
              <span>Go Pro</span>
            </button>
          )}
        </div>
      )}

      {/* Main GENERATE Button */}
      <div className="pt-2">
        <button
          id="generate-button"
          type="button"
          disabled={isGenerating || !description.trim()}
          onClick={() => {
            triggerHaptic("medium");
            onGenerate();
          }}
          className={`w-full py-4 px-5 rounded-xl font-bold text-sm flex items-center justify-center gap-2.5 shadow-lg transition-all cursor-pointer ${
            isGenerating
              ? "bg-zinc-800 text-zinc-400 cursor-not-allowed border border-zinc-700"
              : isLimitReached
              ? "bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white shadow-amber-950/30 active:scale-[0.99]"
              : !description.trim()
              ? "bg-zinc-900 text-zinc-600 cursor-not-allowed border border-zinc-800"
              : "bg-blue-600 hover:bg-blue-500 text-white shadow-blue-900/20 active:scale-[0.99]"
          }`}
        >
          {isGenerating ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Generating with Gemini AI...</span>
            </>
          ) : isLimitReached ? (
            <>
              <Sparkles className="w-4 h-4 text-white" />
              <span>Daily Limit Reached (0/5) — View Pro</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-white" />
              <span>Generate with Gemini AI</span>
            </>
          )}
        </button>

        {!description.trim() && !isLimitReached && (
          <p className="text-xs text-center text-zinc-500 mt-2.5 flex items-center justify-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-zinc-600" />
            Enter a video description to generate captions
          </p>
        )}
      </div>
    </div>
  );
};

import React, { useState, useEffect } from "react";
import { Wifi, Signal, BatteryMedium } from "lucide-react";

export const AndroidStatusBar: React.FC = () => {
  const [timeStr, setTimeStr] = useState<string>("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 10000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div
      id="android-status-bar"
      className="w-full flex items-center justify-between px-6 py-2 select-none text-xs font-semibold text-zinc-400 bg-zinc-950/90 backdrop-blur-md z-30 border-b border-zinc-800/80"
    >
      <div className="flex items-center gap-1.5 font-medium tracking-tight text-zinc-300">
        <span>{timeStr || "09:41"}</span>
      </div>

      {/* Samsung Infinity-O Camera Cutout simulation */}
      <div className="w-3.5 h-3.5 rounded-full bg-zinc-900 ring-1 ring-zinc-700 shadow-inner flex items-center justify-center">
        <div className="w-1.5 h-1.5 rounded-full bg-zinc-950 ring-0.5 ring-blue-900/60" />
      </div>

      <div className="flex items-center gap-2">
        <span className="text-[10px] tracking-wider text-zinc-500 font-bold">5G</span>
        <Signal className="w-3.5 h-3.5 text-zinc-400" />
        <Wifi className="w-3.5 h-3.5 text-zinc-400" />
        <div className="flex items-center gap-1">
          <span className="text-[10px] font-mono text-zinc-400">98%</span>
          <BatteryMedium className="w-4 h-4 text-emerald-400" />
        </div>
      </div>
    </div>
  );
};

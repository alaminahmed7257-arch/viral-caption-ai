import { CaptionResult, DailyUsageInfo } from "../types";

const STORAGE_KEY = "viral_caption_ai_history_v1";
const USAGE_STORAGE_KEY = "viral_caption_ai_daily_usage_v1";
export const DAILY_FREE_GENERATION_LIMIT = 5;

function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function getDailyUsage(): DailyUsageInfo {
  try {
    const today = getTodayDateString();
    const raw = localStorage.getItem(USAGE_STORAGE_KEY);
    if (!raw) {
      return {
        used: 0,
        maxDaily: DAILY_FREE_GENERATION_LIMIT,
        remaining: DAILY_FREE_GENERATION_LIMIT,
        resetDate: today,
      };
    }

    const parsed = JSON.parse(raw);
    // Check if the stored record is from a previous day (or expired > 24 hrs)
    if (parsed.resetDate !== today) {
      const resetInfo: DailyUsageInfo = {
        used: 0,
        maxDaily: DAILY_FREE_GENERATION_LIMIT,
        remaining: DAILY_FREE_GENERATION_LIMIT,
        resetDate: today,
      };
      localStorage.setItem(USAGE_STORAGE_KEY, JSON.stringify(resetInfo));
      return resetInfo;
    }

    const used = typeof parsed.used === "number" ? parsed.used : 0;
    const remaining = Math.max(0, DAILY_FREE_GENERATION_LIMIT - used);

    return {
      used,
      maxDaily: DAILY_FREE_GENERATION_LIMIT,
      remaining,
      resetDate: today,
    };
  } catch (e) {
    console.error("Failed to load daily usage:", e);
    return {
      used: 0,
      maxDaily: DAILY_FREE_GENERATION_LIMIT,
      remaining: DAILY_FREE_GENERATION_LIMIT,
      resetDate: getTodayDateString(),
    };
  }
}

export function incrementDailyUsage(): DailyUsageInfo {
  const current = getDailyUsage();
  const updatedUsed = current.used + 1;
  const updatedRemaining = Math.max(0, DAILY_FREE_GENERATION_LIMIT - updatedUsed);
  const updated: DailyUsageInfo = {
    ...current,
    used: updatedUsed,
    remaining: updatedRemaining,
  };

  try {
    localStorage.setItem(USAGE_STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error("Failed to save daily usage:", e);
  }

  return updated;
}

export function canGenerateToday(): boolean {
  const usage = getDailyUsage();
  return usage.remaining > 0;
}

export function loadHistory(): CaptionResult[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) return getInitialSampleHistory();
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    console.error("Failed to load history:", e);
    return getInitialSampleHistory();
  }
}

export function saveHistory(items: CaptionResult[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch (e) {
    console.error("Failed to save history:", e);
  }
}

export function addHistoryItem(item: CaptionResult): CaptionResult[] {
  const current = loadHistory();
  // Avoid duplicate ID
  const filtered = current.filter((i) => i.id !== item.id);
  const updated = [item, ...filtered];
  saveHistory(updated);
  return updated;
}

export function deleteHistoryItem(id: string): CaptionResult[] {
  const current = loadHistory();
  const updated = current.filter((i) => i.id !== id);
  saveHistory(updated);
  return updated;
}

export function clearAllHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error("Failed to clear history:", e);
  }
}

export function triggerHaptic(type: "light" | "medium" | "heavy" = "light"): void {
  if (typeof window !== "undefined" && "vibrate" in navigator) {
    try {
      if (type === "light") navigator.vibrate(15);
      else if (type === "medium") navigator.vibrate(30);
      else if (type === "heavy") navigator.vibrate([40, 30, 40]);
    } catch {
      // Ignore vibration errors
    }
  }
}

function getInitialSampleHistory(): CaptionResult[] {
  return [
    {
      id: "sample-1",
      title: "🔥 The #1 Phone Trick 99% Of People Still Don't Know",
      caption:
        "Did your phone just do that?! 🤯 Try this hidden setting right now and thank me later. Double tap if this helped you out! Which tip should I uncover next? 👇",
      hashtags: [
        "#techhacks",
        "#androidtips",
        "#samsunggalaxy",
        "#phonetrick",
        "#viral",
        "#techtok",
        "#lifehacks",
        "#trending",
        "#gadgets",
        "#contentcreator",
      ],
      hookAlternatives: [
        "Your phone is secretly hiding this feature from you 🤫",
        "Stop scrolling if you have an Android! 📱",
        "This one setting changes everything... ⚡",
      ],
      videoName: "galaxy_hidden_tips_4k.mp4",
      videoSize: "18.4 MB",
      videoDuration: "0:42",
      description: "Showing 3 secret Samsung Galaxy gestures that speed up multitasking and battery life.",
      tone: "viral",
      targetPlatform: "TikTok / Reels",
      createdAt: Date.now() - 3600000 * 2,
    },
    {
      id: "sample-2",
      title: "🍜 5-Minute Midnight Garlic Butter Noodles (So Good It's Illegal)",
      caption:
        "The crispiest, creamiest noodles you will ever make in under 5 minutes! 🤤 Save this recipe before you forget what you're making tonight. Drop a ❤️ if you're a noodle addict!",
      hashtags: [
        "#foodie",
        "#quickrecipes",
        "#ramenhack",
        "#midnightcravings",
        "#easycooking",
        "#viralrecipe",
        "#delicious",
        "#foodtiktok",
        "#cheflife",
        "#foodporn",
      ],
      hookAlternatives: [
        "Do not make this unless you want to be obsessed! 🍜",
        "The fastest comfort meal on earth 🔥",
        "Your new late-night food addiction has arrived 🤤",
      ],
      videoName: "midnight_noodles_quick.mp4",
      videoSize: "32.1 MB",
      videoDuration: "0:28",
      description: "Quick 5 minute midnight garlic chili oil noodles cooking tutorial in one pan.",
      tone: "viral",
      targetPlatform: "Instagram Reels",
      createdAt: Date.now() - 3600000 * 26,
    },
  ];
}

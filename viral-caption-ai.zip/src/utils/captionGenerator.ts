import { CaptionResult } from "../types";

export interface CaptionGenerationParams {
  description: string;
  videoName?: string;
  tone: string;
  targetPlatform: string;
}

export interface GeneratedCaptionData {
  title: string;
  caption: string;
  hashtags: string[];
  hookAlternatives: string[];
}

export function generateLocalCaptions(params: CaptionGenerationParams): GeneratedCaptionData {
  const cleanDesc = params.description.trim();
  const words = cleanDesc.split(/\s+/).filter((w) => w.length > 2);
  
  // Extract key topic phrase
  const rawSubject = words.slice(0, 4).join(" ");
  const primarySubject = rawSubject
    ? rawSubject.charAt(0).toUpperCase() + rawSubject.slice(1)
    : "This Secret Strategy";

  // Extract keywords for hashtags
  const extractedKeywords = Array.from(
    new Set(
      words
        .map((w) => w.toLowerCase().replace(/[^a-z0-9]/g, ""))
        .filter(
          (w) =>
            w.length >= 3 &&
            w.length <= 15 &&
            !["this", "that", "with", "from", "video", "about", "your", "make", "will", "have", "look", "what", "here", "just", "like", "when", "into", "some"].includes(w)
        )
    )
  );

  const dynamicHashtags: string[] = [];
  // Add extracted keywords first (up to 4)
  for (const kw of extractedKeywords.slice(0, 4)) {
    dynamicHashtags.push(`#${kw}`);
  }

  // Normalize platform key
  const platform = params.targetPlatform.toLowerCase();
  const isTikTok = platform.includes("tiktok");
  const isInstagram = platform.includes("instagram");
  const isYouTube = platform.includes("youtube");
  const isFacebook = platform.includes("facebook");

  // Platform-specific hashtag pools
  let platformTags: string[] = [];
  if (isTikTok) {
    platformTags = ["#fyp", "#foryoupage", "#tiktokviral", "#tiktoktrending", "#xyzbca", "#learnontiktok", "#viralvideo"];
  } else if (isInstagram) {
    platformTags = ["#reelsinstagram", "#reelsviral", "#explorepage", "#instareels", "#creatorsofinstagram", "#trendingreels"];
  } else if (isYouTube) {
    platformTags = ["#shorts", "#youtubeshorts", "#ytshorts", "#viralshorts", "#youtubecreators", "#trending"];
  } else if (isFacebook) {
    platformTags = ["#facebookreels", "#fbwatch", "#viralpost", "#facebookcreators", "#trendingnow", "#fbreels"];
  } else {
    platformTags = ["#viral", "#trending", "#reels", "#shorts", "#fyp", "#explorepage"];
  }

  // Tone-specific secondary tags
  const toneTags: Record<string, string[]> = {
    educational: ["#dailyhacks", "#protips", "#mindblowing", "#creatorguide"],
    funny: ["#comedyvideos", "#relatable", "#laughoutloud", "#viralhumor"],
    aesthetic: ["#aestheticvibes", "#moodyvideo", "#visuals", "#cinematic"],
    storytelling: ["#storytime", "#truestory", "#pov", "#deepthoughts"],
    viral: ["#viralcontent", "#trendingvideo", "#mustwatch"],
    dramatic: ["#shocking", "#unexpected", "#plotwist"],
    inspiring: ["#motivation", "#mindset", "#growth", "#inspiration"],
  };

  const pool = toneTags[params.tone] || toneTags.viral;

  for (const tag of [...platformTags, ...pool]) {
    if (!dynamicHashtags.includes(tag) && dynamicHashtags.length < 10) {
      dynamicHashtags.push(tag);
    }
  }

  // Generate platform-optimized title
  let title = "";
  if (isTikTok) {
    switch (params.tone) {
      case "educational":
        title = `Nobody is talking about this ${primarySubject} hack 🤯`;
        break;
      case "funny":
      case "humorous":
        title = `Wait till the end of this ${primarySubject} 😂💀`;
        break;
      case "dramatic":
        title = `POV: You just discovered ${primarySubject} ⚡`;
        break;
      case "inspiring":
        title = `This will completely change how you see ${primarySubject} ✨`;
        break;
      default:
        title = `Secret ${primarySubject} you NEED to know! 🚀`;
        break;
    }
  } else if (isInstagram) {
    switch (params.tone) {
      case "educational":
        title = `The Complete Guide to ${primarySubject} (Save for later!) 💡`;
        break;
      case "funny":
      case "humorous":
        title = `I wasn't ready for this: ${primarySubject} 😭`;
        break;
      case "dramatic":
        title = `The Untold Truth About ${primarySubject} ⚡`;
        break;
      case "inspiring":
        title = `Golden Hour Glow: Mastering ${primarySubject} ✨`;
        break;
      default:
        title = `Stop Scrolling: The Ultimate ${primarySubject} Breakdown 🔥`;
        break;
    }
  } else if (isYouTube) {
    switch (params.tone) {
      case "educational":
        title = `How To Master ${primarySubject} in 60 Seconds! (Easy Guide) 🚀 #Shorts`;
        break;
      case "funny":
      case "humorous":
        title = `I Tried ${primarySubject} and THIS Happened... 😱 #Shorts`;
        break;
      case "dramatic":
        title = `DO NOT Make This ${primarySubject} Mistake ❌ #Shorts`;
        break;
      case "inspiring":
        title = `How ${primarySubject} Changed Everything (Step-by-Step) ✨ #Shorts`;
        break;
      default:
        title = `${primarySubject} Explained in 30 Seconds! ⚡ #Shorts`;
        break;
    }
  } else if (isFacebook) {
    switch (params.tone) {
      case "educational":
        title = `Everyone needs to know this simple trick for ${primarySubject}! 💡`;
        break;
      case "funny":
      case "humorous":
        title = `This made my whole day: ${primarySubject} 😂`;
        break;
      case "dramatic":
        title = `You won't believe what happened next with ${primarySubject}! ⚡`;
        break;
      case "inspiring":
        title = `A heartwarming reminder about ${primarySubject} to brighten your day ❤️`;
        break;
      default:
        title = `Share this with someone who loves ${primarySubject}! 🔥`;
        break;
    }
  } else {
    title = `Stop Scrolling! ${primarySubject} 🚀`;
  }

  // Generate platform-optimized caption with custom call-to-actions
  let caption = "";
  if (isTikTok) {
    caption = `${cleanDesc}\n\nDid you know this already? Drop a comment below 👇\n\n📌 Save this video or share with a friend who needs it!`;
  } else if (isInstagram) {
    caption = `${cleanDesc}\n\n✨ Key takeaways you don't want to miss!\n\n📌 SAVE this reel for later\n↗️ SHARE with your circle\n💬 Drop your thoughts or questions in the comments!`;
  } else if (isYouTube) {
    caption = `${cleanDesc}\n\n🔔 SUBSCRIBE for new daily videos & tutorials!\n👍 Smash that LIKE button if this helped you!\n💬 What topic should we cover next? Let me know below!`;
  } else if (isFacebook) {
    caption = `${cleanDesc}\n\nWhat are your thoughts on this? Let's discuss in the comments! 💬\n\n👉 Tag a friend who needs to see this today!\n👍 Like and follow for more daily updates!`;
  } else {
    caption = `${cleanDesc}\n\n🔥 Which part surprised you the most? Double tap & share with a friend!`;
  }

  const hookAlternatives = isTikTok
    ? [
        `TikTok made me try this ${primarySubject}...`,
        `3 reasons why ${primarySubject} is going viral.`,
        `Watch until the end if you want to know the secret.`,
      ]
    : isInstagram
    ? [
        `Nobody is talking about this ${primarySubject}...`,
        `Save this reel before it gets lost in your feed!`,
        `3 simple steps to transform your ${primarySubject}.`,
      ]
    : isYouTube
    ? [
        `Wait till you see what happens next!`,
        `The biggest mistake people make with ${primarySubject}.`,
        `Watch this before you start ${primarySubject}!`,
      ]
    : [
        `You won't believe how simple this is...`,
        `Share this with someone who needs this today!`,
        `The real story behind ${primarySubject}.`,
      ];

  return {
    title,
    caption,
    hashtags: dynamicHashtags,
    hookAlternatives,
  };
}

